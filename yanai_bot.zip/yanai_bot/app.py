from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from twilio.rest import Client
import json
import os
from datetime import datetime, date
import threading
import time
import schedule

app = Flask(__name__)

# Twilio credentials
ACCOUNT_SID = os.environ.get('TWILIO_ACCOUNT_SID', 'ACcae0039f7114be79f71b7c6bb424b282')
AUTH_TOKEN = os.environ.get('TWILIO_AUTH_TOKEN', '81358a1f68a4aae611275f59754a4228')
TWILIO_NUMBER = 'whatsapp:+14155238886'
YOUR_NUMBER = os.environ.get('YOUR_WHATSAPP_NUMBER', '')  # תמלא את הנייד שלך

client = Client(ACCOUNT_SID, AUTH_TOKEN)

# Data file paths
TASKS_FILE = 'tasks.json'
MEETINGS_FILE = 'meetings.json'
WORKOUTS_FILE = 'workouts.json'

# ─── Data helpers ───────────────────────────────────────────

def load_data(filepath):
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []

def save_data(filepath, data):
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# ─── Task functions ──────────────────────────────────────────

def add_task(text):
    tasks = load_data(TASKS_FILE)
    task = {
        'id': len(tasks) + 1,
        'text': text,
        'date': str(date.today()),
        'status': 'פתוח'
    }
    tasks.append(task)
    save_data(TASKS_FILE, tasks)
    return f"✅ משימה נוספה: {text}"

def list_tasks():
    tasks = load_data(TASKS_FILE)
    open_tasks = [t for t in tasks if t['status'] == 'פתוח']
    if not open_tasks:
        return "🎉 אין משימות פתוחות!"
    msg = "📋 *המשימות הפתוחות שלך:*\n"
    for t in open_tasks:
        msg += f"{t['id']}. {t['text']}\n"
    return msg

def complete_task(task_id):
    tasks = load_data(TASKS_FILE)
    for t in tasks:
        if t['id'] == int(task_id):
            t['status'] = 'הושלם'
            save_data(TASKS_FILE, tasks)
            return f"✅ משימה {task_id} סומנה כהושלמה!"
    return f"❌ לא מצאתי משימה מספר {task_id}"

# ─── Meeting functions ───────────────────────────────────────

def add_meeting(text, meeting_date, meeting_time):
    meetings = load_data(MEETINGS_FILE)
    meeting = {
        'id': len(meetings) + 1,
        'text': text,
        'date': meeting_date,
        'time': meeting_time
    }
    meetings.append(meeting)
    save_data(MEETINGS_FILE, meetings)
    return f"📅 פגישה נוספה: {text} ב-{meeting_date} בשעה {meeting_time}"

def list_meetings():
    meetings = load_data(MEETINGS_FILE)
    if not meetings:
        return "📅 אין פגישות מתוכננות."
    msg = "📅 *הפגישות שלך:*\n"
    for m in meetings:
        msg += f"{m['id']}. {m['text']} — {m['date']} בשעה {m['time']}\n"
    return msg

# ─── Workout functions ───────────────────────────────────────

def add_workout(workout_type, notes=''):
    workouts = load_data(WORKOUTS_FILE)
    workout = {
        'id': len(workouts) + 1,
        'type': workout_type,
        'date': str(date.today()),
        'notes': notes
    }
    workouts.append(workout)
    save_data(WORKOUTS_FILE, workouts)
    return f"💪 אימון נרשם: {workout_type}!"

def weekly_summary():
    tasks = load_data(TASKS_FILE)
    workouts = load_data(WORKOUTS_FILE)
    meetings = load_data(MEETINGS_FILE)

    completed = [t for t in tasks if t['status'] == 'הושלם']
    open_tasks = [t for t in tasks if t['status'] == 'פתוח']

    msg = "📊 *סיכום שבועי של ינאי:*\n\n"
    msg += f"✅ משימות שהושלמו: {len(completed)}\n"
    msg += f"📋 משימות פתוחות: {len(open_tasks)}\n"
    msg += f"💪 אימונים השבוע: {len(workouts)}\n"
    msg += f"📅 פגישות: {len(meetings)}\n"
    msg += "\nכל הכבוד על השבוע! 🎉"
    return msg

# ─── Message handler ─────────────────────────────────────────

def handle_message(msg):
    msg = msg.strip()

    # משימות
    if msg.startswith('משימה '):
        return add_task(msg[6:])

    elif msg == 'משימות':
        return list_tasks()

    elif msg.startswith('הושלם '):
        task_id = msg.split(' ')[1]
        return complete_task(task_id)

    # פגישות — פורמט: פגישה [שם] [תאריך DD/MM] [שעה HH:MM]
    elif msg.startswith('פגישה '):
        parts = msg.split(' ')
        if len(parts) >= 4:
            name = ' '.join(parts[1:-2])
            meeting_date = parts[-2]
            meeting_time = parts[-1]
            return add_meeting(name, meeting_date, meeting_time)
        return "❓ פורמט: פגישה [שם] [תאריך DD/MM] [שעה HH:MM]\nדוגמה: פגישה דנטיסט 15/04 10:00"

    elif msg == 'פגישות':
        return list_meetings()

    # אימונים
    elif msg.startswith('אימון '):
        parts = msg.split(' ', 2)
        notes = parts[2] if len(parts) > 2 else ''
        return add_workout(parts[1], notes)

    # סיכום שבועי
    elif msg == 'סיכום':
        return weekly_summary()

    # עזרה
    elif msg == 'עזרה' or msg == 'help':
        return (
            "🤖 *הפקודות שלי:*\n\n"
            "📋 *משימות:*\n"
            "• `משימה [טקסט]` — הוסף משימה\n"
            "• `משימות` — רשימת משימות\n"
            "• `הושלם [מספר]` — סמן כהושלם\n\n"
            "📅 *פגישות:*\n"
            "• `פגישה [שם] [DD/MM] [HH:MM]`\n"
            "• `פגישות` — רשימת פגישות\n\n"
            "💪 *אימונים:*\n"
            "• `אימון ריצה [הערות]`\n"
            "• `אימון חדר כושר`\n\n"
            "📊 `סיכום` — סיכום שבועי"
        )

    else:
        return "❓ לא הבנתי. שלח *עזרה* לרשימת הפקודות."

# ─── Flask route ─────────────────────────────────────────────

@app.route('/webhook', methods=['POST'])
def webhook():
    incoming_msg = request.values.get('Body', '')
    response_text = handle_message(incoming_msg)

    resp = MessagingResponse()
    resp.message(response_text)
    return str(resp)

# ─── Run ─────────────────────────────────────────────────────

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
